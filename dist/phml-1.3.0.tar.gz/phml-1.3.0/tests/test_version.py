from phml import __version__

def test_version():
    assert __version__ is not None