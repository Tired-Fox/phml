# PHML with Flask example

This is a higher level example of a potential real use case of using phml.

Make sure to `python3 -m pip install --upgrade flask`
Use `flask run` to start the flask app

Features displayed:
* Components
* Loops
* Conditions
* Nested Components
* Passing additional information to compiler