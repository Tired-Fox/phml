# PHML for loop condition

This example shows how a `py-for` or `@for` can be used in phml.
This also proves to be a stress test. When running the `gen.py` file
it will also time how long it takes to generate all `10,000` unicode characters.

There is also a small amount of javascript to allow for copying of symbols. Feel
free to use the generated html as a cheat sheet.

Enjoy!