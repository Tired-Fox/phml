class TestClasses:
    """Test the phml.utils.misc.classes module."""
    # classnames
    # classList
class TestComponent:
    """Test the phml.utils.misc.component module."""
    # tag_from_file
    # filename_from_path
    # parse_component
    
class TestHeading:
    """Test the phml.utils.misc.heading module."""
    # heading rank