# test

class TestValidate:
    """Test the phml.utils.validate.validate module."""
    
    # validate
    # parent
    # literal
    # generated
    # has_property
    # is_heading
    # is_css_link
    # is_css_style
    # is_javascript
    # is_element
    # is_event_handler