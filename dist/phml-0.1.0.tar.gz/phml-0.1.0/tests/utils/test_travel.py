# path
# walk
# visit_children
# visit_all_after