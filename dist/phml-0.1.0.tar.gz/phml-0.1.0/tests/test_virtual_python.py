# VirtualPython
# get_vp_result
# process_vp_blocks