# TODO

- [ ] Code safe escaping
  - All string values passed in are escaped
  - User can define regular escape or remove tags
  - User can mark the string as safe and stop escaping
  - Use `html` modules escaping
- [ ] Reformat and Design code base
  - Better naming
  - Better structure
  - Abstractions
  - File structure
- [ ] Ability to use flask???
  - Adapt flask to work with phml or think about new project?
- [ ] Refine component system

- [ ] More formats
  - XML support
  - Markdown Support