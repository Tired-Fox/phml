# phml component example

Here is a working example of how to make `phml` components that can be used over and over again.

The `components` that are reused are in the `components/` directory and the `phml` pages are in the `pages/`
directory.

The rendered pages are in the `site/` directory and the `site/index.html` can be used as a home page.
This give a working live example of what `phml` is capable of.